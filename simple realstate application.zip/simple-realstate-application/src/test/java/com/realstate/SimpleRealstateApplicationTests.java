package com.realstate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleRealstateApplicationTests {

	@Test
	void contextLoads() {
	}

}
